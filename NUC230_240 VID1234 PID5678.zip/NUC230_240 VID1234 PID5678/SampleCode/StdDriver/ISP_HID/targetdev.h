
#include "NUC230_240.h"
#include "hid_transfer.h"
#include "ISP_USER.h"

#define DetectPin   				PA1
