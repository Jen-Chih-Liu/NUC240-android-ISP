/** Automatically generated file. DO NOT MODIFY */
package com.yarin.android.Examples_04_01;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}